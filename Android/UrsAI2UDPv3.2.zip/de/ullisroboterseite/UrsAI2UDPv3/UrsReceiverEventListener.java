package de.ullisroboterseite.UrsAI2UDPv3;

import java.net.*;

public interface UrsReceiverEventListener {
    public void ServerStarted(String LocalIP, int LocalPort);

    public void PacketReceived(DatagramPacket Data);

    // ErrorCode: 0, wenn normal abgebrochen, 1: bei Fehler
    public void ListenerThreadStopped(int ErrorCode);

    // DEBUG
    //public void DebuggerLog(String Source, String Msg);
};